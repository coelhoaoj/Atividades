import java.util.Scanner;
public class exe1 {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int codigo;
	double salarioatual=0;
	
	System.out.println("Informe o c�digo do seu cargo: ");
	codigo = sc.nextInt();
	
	switch (codigo) {
	
	 case 1:
		    System.out.println("seu cargo � escrituario");
		    System.out.println("informe seu salario atual: ");
		    salarioatual = sc.nextDouble();
		    System.out.println("seu novo salario �: "+(salarioatual*0.50+salarioatual));
		        break;
		    case 2:
		    	 System.out.println("seu cargo � secretario");
				    System.out.println("informe seu salario atual: ");
				    salarioatual = sc.nextDouble();
				    System.out.println("seu novo salario �: "+(salarioatual*0.35+salarioatual));
				        break;
		    case 3:
		    	 System.out.println("seu cargo � caixa");
				    System.out.println("informe seu salario atual: ");
				    salarioatual = sc.nextDouble();
				    System.out.println("seu novo salario �: "+(salarioatual*0.20+salarioatual));
				        break;
		    case 4:
		    	 System.out.println("seu cargo � gerente");
				    System.out.println("informe seu salario atual: ");
				    salarioatual = sc.nextDouble();
				    System.out.println("seu novo salario �: "+(salarioatual*0.10+salarioatual));
				        break;
		    case 5:
		    	 System.out.println("seu cargo � diretor");
				    System.out.println("informe seu salario atual: ");
				    salarioatual = sc.nextDouble();
				    System.out.println("seu novo salario �: ");
				        break;

		    }
		    sc.close();
		    }
		    }