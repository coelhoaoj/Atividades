
import java.util.Scanner;

public class exei {
	
	public static void main(String[] args) {
		System.out.print("Insira o valor do sal�rio m�nimo: ");
		Scanner input2 = new Scanner(System.in);
		int min = input2.nextInt();
		
		System.out.print("Insira o n�mero de horas trabalhadas: ");
		Scanner input1 = new Scanner(System.in);
		float hours = input1.nextFloat();
		
		System.out.print("Insira o valor de horas extra trabalhadas: ");
		Scanner input3 = new Scanner(System.in);
		int extra = input3.nextInt();
		
		float hoursValue = hours * (min / 8);
		// 2h * 80/8 = 2 * 10 = 20 
		float extraValue = extra * (min / 4);
		// 2h * 80/4 = 2 * 20 = 40
		float salary = hoursValue + extraValue ;
		
		System.out.print(salary);
	}
	
}
