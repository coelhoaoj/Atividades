
import java.util.Scanner;

public class exel {
	public static void main(String[] args) {
		System.out.print("Insira o custo do espet�culo: ");
		Scanner input1 = new Scanner(System.in);
		float cost = input1.nextFloat();
		
		System.out.print("Insira o valor do ingresso: ");
		Scanner input2 = new Scanner(System.in);
		float ticket = input2.nextFloat();
		
		float min = cost / ticket;
		
		System.out.print(min);
	}
	
}
