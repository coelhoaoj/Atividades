import java.util.Scanner;
public class exed {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		double x, result;
		System.out.println("Informe o pre�o da gasolina:");
		x = sc.nextDouble();
		result = x*0.10;

		System.out.println(result);

sc.close();	
	}

}
