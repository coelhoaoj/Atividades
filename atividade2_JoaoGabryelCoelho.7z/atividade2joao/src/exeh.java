import java.util.Scanner;

public class exeh {

	public static void main(String[] args) {
		System.out.print("Digite o valor do sal�rio: ");
		Scanner input1 = new Scanner(System.in);
		float salary = input1.nextFloat();
		
		System.out.print("Digite o valor da primeira conta: ");
		Scanner input2 = new Scanner(System.in);
		float bill1 = input2.nextFloat();
		
		System.out.print("Digite o valor da segunda conta: ");
		Scanner input3 = new Scanner(System.in);
		float bill2 = input3.nextFloat();
		
		float result1 = bill1 + (bill1/50);
		float result2 = bill2 + (bill2/50);
		
		System.out.print(salary - result1 - result2);

	}

}
