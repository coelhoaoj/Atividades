
import java.util.Scanner;

public class exem {

	public static void main(String[] args) {
		System.out.print("Insira o valor do sal�rio m�nimo: ");
		Scanner input1 = new Scanner(System.in);
		float min = input1.nextFloat();
		
		System.out.print("Insira a quantidade de quilowatts consumidos: ");
		Scanner input2 = new Scanner(System.in);
		float kw = input2.nextFloat();
		
		float kwPrice = min / 5;
		float total = kwPrice * kw;
		float discount = total - (total / 100 * 15);
		
		System.out.print("pre�o do kW: " + kwPrice + "\nvalor a ser pago: " + total + "\nvalor com desconto: " + discount);
	}

}
