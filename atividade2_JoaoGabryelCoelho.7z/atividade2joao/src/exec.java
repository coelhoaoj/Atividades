import java.util.Scanner;
public class exec {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		double x, y, result;
		System.out.println("Informe um n�mero (n�o pode ser 0):");
		x = sc.nextDouble();
		System.out.println("Informe um n�mero:");
		y = sc.nextDouble();
		result = x/y;

		System.out.println(result);

sc.close();	
	}

}
