
import java.util.Scanner;

public class exen {

	public static void main(String[] args) {
		System.out.print("Insira o peso do saco de ra��o em gramas: ");
		Scanner input1 = new Scanner(System.in);
		int weight = input1.nextInt();
		
		System.out.print("Insira a quantidade di�ria de ra��o para cada gato em gramas: ");
		Scanner input2 = new Scanner(System.in);
		int amount = input2.nextInt();
		
		int left = weight - (amount * 10);
		
		System.out.print(left);
	}

}
