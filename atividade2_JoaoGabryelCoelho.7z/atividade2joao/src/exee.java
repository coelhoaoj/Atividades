import java.util.Scanner;
public class exee {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		double x, y, result;
		System.out.println("Informe o seu sal�rio fixo:");
		x = sc.nextDouble();
		System.out.println("Informe o valor de suas vendas:");
		y = sc.nextDouble();
		result = x+y*0.4;
		System.out.println(y);
		System.out.println(result);

sc.close();	
	}

}
