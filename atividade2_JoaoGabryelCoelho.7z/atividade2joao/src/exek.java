
import java.util.Scanner;

public class exek {

	public static void main(String[] args) {
		System.out.print("Insira o valor das horas do hor�rio: ");
		Scanner input1 = new Scanner(System.in);
		int hours = input1.nextInt();
		
		System.out.print("Insira o valor dos minutos do hor�rio: ");
		Scanner input2 = new Scanner(System.in);
		int min = input2.nextInt();
		
		int hourToMinute = hours * 60;
		int minutes = hourToMinute + min;
		int seconds = minutes * 60;
		
		System.out.print("hora convertida: " + hourToMinute + "\nminutos totais: " + minutes + "\nsegundos: " + seconds);
		
	}

}
