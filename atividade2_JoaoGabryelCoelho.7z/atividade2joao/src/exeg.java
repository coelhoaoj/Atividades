
import java.util.Scanner;
public class exeg {

	public static void main(String[] args) {
		System.out.print("Digite um n�mero: ");
		Scanner input = new Scanner(System.in);
		int num = input.nextInt();
		
		System.out.print(num * 1 + "\n");
		System.out.print(num * 2 + "\n");
		System.out.print(num * 3 + "\n");
		System.out.print(num * 4 + "\n");
		System.out.print(num * 5 + "\n");
		System.out.print(num * 6 + "\n");
		System.out.print(num * 7 + "\n");
		System.out.print(num * 8 + "\n");
		System.out.print(num * 9 + "\n");
		System.out.print(num * 10 + "\n");
	}

}
