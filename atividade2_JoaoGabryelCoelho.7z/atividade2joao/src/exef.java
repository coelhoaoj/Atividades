import java.util.Scanner;
public class exef {

		public static void main(String[] args) {
			System.out.print("Digite o valor do sal�rio m�nimo: ");
			Scanner input1 = new Scanner(System.in);
			float min = input1.nextFloat();
			
			System.out.print("Digite o sal�rio recebido: ");
			Scanner input2 = new Scanner(System.in);
			float salary = input2.nextFloat();
			
			float result = salary / min;
			
			System.out.print(result);

		}

	}
