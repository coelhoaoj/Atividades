import java.util.Scanner;

public class exej {

	public static void main(String[] args) {
		System.out.print("Insira o valor que possui em reais: ");
		Scanner input = new Scanner(System.in);
		double brl = input.nextDouble();

		double eur = brl * 0.19;
		double usd = brl * 0.2;
		double gbp = brl * 0.16;
		
		System.out.print("euro: " + eur + "\nd�lar: " + usd + "\nlibra: " + gbp);
	}

}
