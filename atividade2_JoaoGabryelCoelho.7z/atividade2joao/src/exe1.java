import java.util.Scanner;
public class exe1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		double x, y, result;
		System.out.println("Informe um n�mero:");
		x = sc.nextDouble();
		System.out.println("Informe um n�mero:");
		y = sc.nextDouble();
		result = x+y;
		System.out.println(result);

sc.close();	
	}

}
