import java.util.Scanner;
public class exeb {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		double v, w, x, y, z, result;
		System.out.println("Informe um n�mero:");
		v = sc.nextDouble();
		System.out.println("Informe um n�mero:");
		w = sc.nextDouble();
		System.out.println("Informe um n�mero:");
		x = sc.nextDouble();
		System.out.println("Informe um n�mero:");
		y = sc.nextDouble();
		System.out.println("Informe um n�mero:");
		z = sc.nextDouble();
		result = (v+w+x+y+z)/8;
		System.out.println(result);

sc.close();	
	}

}
