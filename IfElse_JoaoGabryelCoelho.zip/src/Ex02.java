import java.util.Scanner;
public class Ex02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int dia, ano, hora, min;
		String mes;

		
		System.out.println("Digite o dia: ");
		dia = sc.nextInt();
		
		System.out.println("Digite o mes por extenso: ");
		mes = sc.next();
		
		System.out.println("Digite o ano: ");
		ano = sc.nextInt();
		
		System.out.println("Digite a hora: ");
		hora = sc.nextInt();
		
		System.out.println("Digite os minutos: ");
		min = sc.nextInt();
		
		System.out.println(dia+"/"+mes+"/"+ano);
		System.out.println(hora+":"+min);
		}

}