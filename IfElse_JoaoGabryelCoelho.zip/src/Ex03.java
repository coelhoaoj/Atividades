import java.util.Scanner;
public class Ex03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int dia1,mes1,ano1;
		int dia2,mes2,ano2;
		
		System.out.println("-----> Digite a primeira data <-----");
		System.out.println("Digite o dia: ");
		dia1 = sc.nextInt();
		
		System.out.println("Digite o mes: ");
		mes1 = sc.nextInt();
		
		System.out.println("Digite o ano: ");
		ano1 = sc.nextInt();
	
		
		System.out.println("-----> Digite a segunda data <-----");
		System.out.println("Digite o dia: ");
		dia2 = sc.nextInt();
		
		System.out.println("Digite o mes: ");
		mes2 = sc.nextInt();
		
		System.out.println("Digite o ano: ");
		ano2 = sc.nextInt();
		
		if(dia1 > dia2 && mes1 == mes2 && ano1 == ano2 || dia1==dia2 && mes1>mes2 && ano1==ano2 ||dia1==dia2 && mes1==mes2 && ano1>ano2) {
			System.out.println("Primeira data � maior!");
			System.out.println(dia1+"/"+mes1+"/"+ano1);
		}else {
			System.out.println("Segunda data � maior");
			System.out.println(dia2+"/"+mes2+"/"+ano2);
		}
		
		sc.close();
	}
}