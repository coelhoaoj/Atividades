import java.util.Scanner;
public class Ex01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int escolha, num1, num2, soma;
		double numraiz, raiz;
		
		System.out.println("1 - Somar dois numeros?");
		System.out.println("2 - Raiz quadrada de um numero?");
		System.out.println("Digite a opção desejada(1 ou 2):");
		escolha = sc.nextInt();
		
		if(escolha == 1) {
			System.out.println("-----> Somar dois numeros <-----");
			System.out.println("Digite um numero :");
			num1 = sc.nextInt();
			
			System.out.println("Digite mais um numero: ");
			num2 = sc.nextInt();
			
			soma = num1 + num2;
			
			System.out.println("A soma �: "+soma);
		} else if(escolha == 2) {
			System.out.println("Digite um numero: ");
			numraiz = sc.nextInt();
			
			raiz = Math.sqrt(numraiz);
			
			System.out.println("A raiz quadra desse numero é:"+raiz);	
		}
		
	}

}